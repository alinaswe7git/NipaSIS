<form id="recover" name="recover" method="post" action="">
	<p>Please provide the needed information to recover your account password.</p>

	<table width="700" border="0" cellpadding="5" cellspacing="0">

		<tr>
			<td><strong>National Registration Number</strong></td>
			<td>
				<input type="text" name="uid"/>
			</td>
		</tr>
		<tr>
			<td><strong>Student ID or Username</strong></td>
			<td>
				<input type="text" name="username"/></td>
		</tr>
	</table>

<br>
	<p>Click on the button below to complete your password recovery request. </p>

	<input type="submit" id="submit" class="submit" value="Recover password"/>

	<p>&nbsp;</p>

</form>