<form id="login" name="login" method="get"  action="<?php echo $this->core->conf['conf']['path'] . "/grades/results/"; ?>">
	<div class="label">Enter student number:</div>
	<input type="text" name="uid" id="student-id" class="submit" style="width: 125px"/>
	<input type="submit" class="submit" value="Open record"/>
</form>
