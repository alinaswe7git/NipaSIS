<div class="btn-intake">

<a href="<?php echo $this->core->conf['conf']['path']; ?>/startregistration/create" class="btn btn-primary" role="button"> <b> Start Application </b></a> 
<a href="<?php echo $this->core->conf['conf']['path']; ?>/startregistration/login" class="btn btn-primary" role="button"> <b> Continue Application </b></a> 

</div>

<style>

.btn-intake{
    padding: 10px;
}

</style>
