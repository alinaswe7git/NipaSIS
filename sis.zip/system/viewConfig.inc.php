<?php

class viewConfig {

	public $title;
	public $description;
	public $open;
	public $header;
	public $breadcrumb;
	public $footer;
	public $menu;
	public $javascript;
	public $css;
}

?>